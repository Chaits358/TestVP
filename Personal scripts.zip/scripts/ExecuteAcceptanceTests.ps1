. .\GetLatestBuild.ps1

function UnZipMe($zipfilename,$destination)
{
    $shellApplication = new-object -com shell.application;
	$zipPackage = $shellApplication.NameSpace($zipfilename);
	$destinationFolder = $shellApplication.NameSpace($destination);
	$destinationFolder.CopyHere($zipPackage.Items(),0x14);
}

Write-Host "Executing the acceptance tests on the Simplification.IntegrationTest Build Number" $($env:IntegrationBuildNumber)
Write-Host "Creating FOLDERS" -ForegroundColor Yellow
$from="F:\Utils\CompiledTests\"
Remove-Item $from"**" -Force -Recurse  -Verbose
write-host "Remove-Item $from -Force -Recurse  -Verbose"
New-Item -Force -ItemType directory -Path "F:\Utils\CompiledTests"
New-Item -Force -ItemType directory -Path "C:\Aggregator\Data"

Write-Host "Downloading ARTEFACTS from Artefactory" -ForegroundColor Yellow
$artifactoryURL="http://usdml.bpweb.bp.com:8088/artifactory"
$buildName="Simplification.AggregatorAcceptance.Build"
$buildNumber = latestBuild $artifactoryURL $buildName

write-host "Getting build $($buildNumber) of $($buildName)"
$url="$($artifactoryUrl)/api/search/prop?build.name=$($buildName)&build.number=$($buildNumber)"
$response = Invoke-RestMethod -uri $url
$downloadUri = (Invoke-RestMethod -Uri $response.results[0].uri).downloadUri
write-host "Download URI for the Aggregator build is $($downloadUri)"
Invoke-RestMethod -uri $downloadUri  -OutFile F:\utils\AggregatorAcceptance.zip

Write-Host "Unzipping the files to F:\Utils\CompiledTests" -ForegroundColor Yellow
UnZipMe -zipfilename "F:\utils\AggregatorAcceptance.zip" -destination "F:\Utils\CompiledTests"

Write-Host "Running TESTS after copying the Artefacts" -ForegroundColor Yellow
