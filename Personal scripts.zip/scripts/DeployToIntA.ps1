. .\GetLatestBuild.ps1
. .\DeploySnapshotVersion.ps1
$artifactoryUrl="http://usdml.bpweb.bp.com:8088/artifactory"
$buildName="Simplification.IntegrationTest"
$repo="bp-mrisk-snapshot"
$buildNumber=latestBuild $artifactoryUrl $buildName $repo
"IntegrationBuildNumber=$($buildNumber)" | Out-File F:\Apps\deployedBuild.properties -Encoding ASCII

deploySnapshot "INTA" $buildNumber
return $buildNumber
