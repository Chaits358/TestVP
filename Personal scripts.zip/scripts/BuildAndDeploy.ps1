### NOT USED NOW ####
Echo "Initialising variables..."
echo "Environment being run on is" $Env:Environment
echo "Version run is" $Env:Version
$mainzipartifact = "F:\GtelApp\mrisk-continuous-deployment.zip"
$sourcelocation = "F:\GtelApp\continuous-deployment"
$bulkInputs = "C:\Aggregator\Data\BulkInputs\"
$configLocation = "$sourcelocation\config"

#Function to unzip Files
function UnzipFiles($zipfilename, $destination)
{
    $shell = new-object -com shell.application
	$zip = $shell.NameSpace($zipfilename)
	foreach($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}


#stopping service 
./StopServices.ps1


#removing service
./UninstallServices.ps1

#Cleaning up old directory
Echo "Removing old files file..."
Remove-Item $mainzipartifact -Recurse -ErrorAction SilentlyContinue
Remove-Item $sourcelocation -Recurse -ErrorAction SilentlyContinue

#To download the zip file
Echo "Downloading the main zip file..."
if($Env:Version -like '*SNAPSHOT*') {
	Invoke-RestMethod http://dml.bpweb.bp.com:8088/artifactory/simple/bp-mrisk-snapshot/com/bp/risk/mrisk-continuous-deployment/$Env:Version/mrisk-continuous-deployment-$Env:Version-build.zip -OutFile F:\GtelApp\\mrisk-continuous-deployment.zip
} else {
	Invoke-RestMethod http://dml.bpweb.bp.com:8088/artifactory/simple/bp-mrisk-release/com/bp/risk/mrisk-continuous-deployment/$Env:Version/mrisk-continuous-deployment-$Env:Version-build.zip -OutFile F:\GtelApp\\mrisk-continuous-deployment.zip
}

#Unzip the main file
Echo "Unzipping the main zip file...Time is now " Get-Date 
New-Item -ItemType directory -Path $sourcelocation
UnzipFiles $mainzipartifact $sourcelocation
Echo "Finished Unzipping the main zip file...Time is now " Get-Date 

#Downloading Environment specific config zip file
Echo "Downloading the config jar file..."
if($Env:Version -like '*SNAPSHOT*') {
	Invoke-RestMethod http://dml.bpweb.bp.com:8088/artifactory/simple/bp-mrisk-snapshot/com/bp/risk/mrisk-config/$Env:Version/mrisk-config-$Env:Version-$Env:Environment.zip -OutFile $sourcelocation\\mrisk-config.zip
} else {
	Invoke-RestMethod http://dml.bpweb.bp.com:8088/artifactory/simple/bp-mrisk-release/com/bp/risk/mrisk-config/$Env:Version/mrisk-config-$Env:Version-$Env:Environment.zip -OutFile $sourcelocation\\mrisk-config.zip
}


#Unzip the main file
Write-Host "Unzipping the config jar file...Time is now ${Get-Date} " Get-Date 
UnzipFiles $sourcelocation\mrisk-config.zip $sourcelocation
Write-Host "Finished Unzipping the config jar file...Time is now " Get-Date 
Remove-Item $sourcelocation\mrisk-config.zip -Recurse -ErrorAction SilentlyContinue
Remove-Item $sourcelocation\META-INF -Recurse -ErrorAction SilentlyContinue

#Renaming jar
Write-Host "Renaming jars"
$filter = "mrisk-orchestration-aggregator"
$loaderFilter = "mrisk-loader"
$cacheFilter = "mrisk-cache"
Get-ChildItem -Path $sourcelocation | Where-Object { $_.Name -match $filter } | Rename-Item -Newname mrisk-orchestration-aggregator.jar
Get-ChildItem -Path $sourcelocation | Where-Object { $_.Name -match $loaderFilter } | Rename-Item -Newname mrisk-loader.jar
Get-ChildItem -Path $sourcelocation | Where-Object { $_.Name -match $cacheFilter } | Rename-Item -Newname mrisk-cache.jar

#Create log directory
New-Item $sourcelocation\logs -type directory

#installing service
./InstallServices.ps1


#starting service
./StartServices.ps1

