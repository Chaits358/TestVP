. .\UpdateCommandCenter.ps1
#using WebRequest as invoke-restmethod fails for non GET calls after 3 calls
function setProperties([string]$uri, [string]$credAuth) {
    $request = [System.Net.WebRequest]::Create($uri)
    $request.Method="PUT"
    $request.Headers.Add("Authorization","Basic $credAuth")
    $response = $request.GetResponse()
    $response.Dispose()
}

try {
	$user="tfjenkins"
	$pass=$env:tfjenkins
	$passSS = ConvertTo-SecureString $pass -AsPlainText -Force
	$cred=New-Object System.Management.Automation.PSCredential ($user, $passSS)
	$credAuth=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($user):$($pass)"))

	$artifactoryUrl="http://usdml.bpweb.bp.com:8088/artifactory"
	$jobName="Simplification.IntegrationTest"
	$snapshotRepo="bp-mrisk-snapshot"
	$buildNumber=$($env:IntegrationBuildNumber)
	if ($buildNumber -eq "") {
		write-host "Build number is missing in the input"
		exit 1
	}
	$releaseTag="Simplification.IntegrationTest_$($buildNumber)"
	$ReleaseRepo="bp-mrisk-release"

	# Build promotion if necessary
	write-host "Promoting build $($buildNumber) of $($jobName)"
	$promoteUrl="$($artifactoryUrl)/api/plugins/build/promote/snapshotToRelease/$($jobName)/$($buildNumber)"
	write-host "Promotion URL: $promoteUrl"
	try {
		invoke-restmethod -uri $promoteUrl -Headers @{"Authorization"="Basic $credAuth"}  -Method Post -DisableKeepAlive
		write-host "Promotion of $($releaseTag) is successful"
	}
	catch {
		$result = $_.Exception.Response.GetResponseStream()
		$reader = New-Object System.IO.StreamReader($result)
		$responseBody = ConvertFrom-Json $reader.ReadToEnd();

		write-Error "Error while promoting build [$buildNumber] of [$jobName]: $($responseBody.errors.message)"
	}

	write-host "Setting new version in pom"
	cd $env:workspace

	invoke-expression -Command "C:\apache-maven-3.2.3\bin\mvn.bat --batch-mode release:update-versions -DautoVersionSubmodules=true"
	write-host "POMs updated to version $($newVersion)"

	gci -recurse -filter "pom.xml" | %{ invoke-expression "git add $($_.fullname)"}

	$checkinCmd="git commit --author=`"TF Jenkins <BP1\tfjenkins>`" -m `"Updated poms to version $($newVersion)`""
	write-host $checkinCmd
	invoke-expression -Command $checkinCmd

	Write-Host "Setting the release property on the promoted artifacts"
	$buildSearch="$($artifactoryUrl)/api/build/$($jobName)/$($buildNumber)-r"
	write-host $buildSearch

	try {
		$buildInfo=(Invoke-RestMethod -uri $buildSearch -Headers @{"Authorization"="Basic $credAuth"} -DisableKeepAlive).buildInfo
	}
	catch {
		write-host "Error while retrieving Build Info: $($error[0])"
		exit 1
	}

	foreach ($module in $buildInfo.modules) {
		$moduleName=$module.id.split(":")[1]
		write-output "Processing module $($moduleName)"
		foreach($artifact in $module.artifacts) {
			write-output "Processing Artifact $($artifact.name)"
			$md5=$artifact.md5
			try {
				$urls = (Invoke-RestMethod -uri "$($artifactoryURL)/api/search/checksum?md5=$($md5)&repos=$($ReleaseRepo)" -DisableKeepAlive).results
				
				foreach($u in $urls) {
					try {
						$modulePty=(Invoke-RestMethod -uri "$($u.uri)?properties" -DisableKeepAlive).properties.module
					}
					catch {
						write-host "Module property not found. Using the module name"
						$modulePty=$moduleName
					}
					setProperties "$($u.uri)?properties=release.$($releaseTag)=$($modulePty)" $credAuth
				}
			}
			catch {
				write-host "Error while tagging artifact $($artifact.id) for release $($releaseTag)=$($modulePty): $($error[0])"
				break
				exit 1
			}
		}
	}

	updateCommandCenter $buildNumber
}
catch {
   write-host "Error during script execution: $($Error[0])"
   exit 1
}

