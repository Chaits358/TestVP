. .\GetLatestBuild.ps1

#constants
$artifactoryUrl="http://usdml.bpweb.bp.com:8088/artifactory"

$user="tfjenkins"
$pass="Welcome1"
$passSS = ConvertTo-SecureString $pass -AsPlainText -Force
$cred=New-Object System.Management.Automation.PSCredential ($user, $passSS)
$credAuth=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($user):$($pass)"))

$jobName="Simplification.AggregatorWebService"
$repo="bp-mrisk-release"
$aggregatorWebAutomationbuildNumber=latestBuild $artifactoryUrl $jobName $repo
$aggregatorWebAutomationbuildNumber="AggregatorWebAutomationVersion=$($aggregatorWebAutomationbuildNumber)"
$aggregatorWebAutomationbuildNumber | Out-File F:\Apps\AggregatorBuildNumber.txt

$jobName="Simplification.AggregatorBuildAndDeploy"
$repo="bp-mrisk-snapshot"
$aggregatorBuildNumber=latestBuild $artifactoryUrl $jobName $repo

write-host "Getting build $($aggregatorBuildNumber) of $($jobName)"

$url="$($artifactoryUrl)/api/search/prop?build.name=$($jobName)&build.number=$($aggregatorBuildNumber)"
$response = Invoke-RestMethod -uri $url
$downloadUri = (Invoke-RestMethod -Uri $response.results[0].uri).downloadUri
write-host "Download URI for the Aggregator build is $($downloadUri)"
Invoke-RestMethod -uri $downloadUri -OutFile C:\Aggregator\MVaR_App.accdb

Add-Content F:\Apps\AggregatorBuildNumber.txt "AggregatorBuildNumber=$aggregatorBuildNumber"
