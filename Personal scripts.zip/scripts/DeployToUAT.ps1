
#constants
$baseUrl = "http://sentosa.am.ist.bp.com/cc/api/commandcenterapi.svc/cc/"
$complete = 4

#package urls & key
$startUrl = $baseUrl + "{key}/ex/?action=Start&parameters=buildNumber=$($AggregatorBuildNumber)"
$statusUrl = $baseUrl + "{key}/{packageInstanceId}/status/"
$key="DeployINTAAMDCMarketRiskGTELILApp"
Write-Host "Calling Command Center Package $($key)"

$startUrl = $startUrl.Replace( "{key}", $key )
$statusUrl = $statusUrl.Replace( "{key}", $key )

#execute the job, setup the status url
$response = Invoke-RestMethod $startUrl -Method Get -UseDefaultCredentials
$statusUrl = $statusUrl.Replace( "{packageInstanceId}", $response.InstanceId )
Write-Host "Started, Package Instance is: ", $response.InstanceId
Write-Host "statusUrl is " $statusUrl
#wait for complete
Write-Host -NoNewline "Working"
while( $response.Status -lt $complete )
{
	Write-Host -NoNewline "."
	$response = Invoke-RestMethod $statusUrl -Method Get -UseDefaultCredentials
	Start-Sleep -m 1000
}


#this is just a recursive dump of the adapter status
Write-Host ""
Write-Host "Package Complete:"
$adapterStatusList = new-object System.Collections.Generic.Stack[System.Collections.IList]
$adapterStatusList.Push( $response.Adapters )
while( $adapterStatusList.Count -gt 0 )
{
    $adapters = $adapterStatusList.Pop();
    foreach( $asm in $adapters )
    {
        Write-Host "Adapter Id: ", $asm.PackageAdapterId, "   Status:" $asm.StatusText, "   Message:", $asm.Message

        if( $asm.Adapters.Count -gt 0 )
        {
            $adapterStatusList.Push( $asm.Adapters );
        }
    }
}