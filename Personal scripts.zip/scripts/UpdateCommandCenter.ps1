function updateCommandCenter([string]$buildNumber, [bool]$isProd) {
    Write-Host $buildNumber
    Write-Host $isProd
    $releaseTag="Simplification.IntegrationTest_$($buildNumber)"
    Write-Host "Updating Sentosa/CommandCenter with release tag across all environments $($releaseTag)"
    $rootUrl="http://sentosa.am.ist.bp.com/api/SentosaApi.svc"
    $jsonHeader=@{"Content-Type" = "Application/json"}

    $compName="GTEL Market Risk - IL App.VersionParam"

    $compItems=Invoke-RestMethod -uri "$($rootUrl)/cmp/i/?name=$($compName)" -UseDefaultCredentials -DisableKeepAlive
    foreach($cd in $compItems.ConfigData) {
        if (($isProd -and $cd.Value -in ("PROD (AMDC)", "DR (AMDC)")) -or (!$isProd -and $cd.Value -notin ("PROD (AMDC)", "DR (AMDC)"))) {
            if ($cd.PNameComponentConfigTypeName -eq "Application" -and $cd.PValueComponentConfigTypeName -eq "Instance") {
                write-host $cd.Value
                $AppInstance=$cd.Children
                foreach($ai in $AppInstance) {
                    if($ai.PNameComponentConfigTypeName -eq "Account" -and $ai.PValueComponentConfigTypeName -eq "App Config" -and $ai.Value -match "Simplification.IntegrationTest_") {
                        write-output "$($ai.PropertyId) - $($ai.Value) - $($ai.Id)"
                        $json=@{"Id"= $ai.id;"IsActive"= $ai.IsActive; "IsEnabled"= $ai.IsEnabled; "ParentId"= $ai.ParentId; "PropertyId"= $ai.PropertyId; "Value" = "$($releaseTag)"; "AutoCollectFirstDttm" = "/Date($(([DateTimeOffset](get-date)).ToUnixTimeMilliseconds())-0500)/"; "AutoCollectLastDttm" = "/Date($(([DateTimeOffset](get-date)).ToUnixTimeMilliseconds())-0500)/"}
                        $configUri="$($rootUrl)/cmp/config"
                        $ServicePoint = [System.Net.ServicePointManager]::FindServicePoint($configUri)
                        Invoke-RestMethod -uri $configUri -Method Put -Body $(ConvertTo-Json $json) -UseDefaultCredentials -Headers $jsonHeader -DisableKeepAlive
						$ServicePoint.CloseConnectionGroup("")
                    }
                }
            }
        }
    }
}
