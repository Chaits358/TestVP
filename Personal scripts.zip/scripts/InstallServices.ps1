$sourcelocation = "F:\GtelApp\continuous-deployment"
$wrapperlocation = "F:\wrapper-windows-x86-32-3.5.27"

function installServices()
{
	Write-Output "Installing services"
    cd $wrapperlocation
	.\bin\wrapper.exe -i $sourcelocation\config\loader.conf
	.\bin\wrapper.exe -i $sourcelocation\config\orchestration.conf
	.\bin\wrapper.exe -i $sourcelocation\config\cache.conf
}

installServices
