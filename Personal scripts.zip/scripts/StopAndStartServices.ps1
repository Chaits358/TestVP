write-host "Stopping Services"
Invoke-Command -scriptblock {(get-service -name "AggregationAutomationService", "CacheService", "LoaderService").Stop()} -asjob;

write-host "Starting Services"
Invoke-Command -scriptblock {(get-service -name "AggregationAutomationService", "CacheService", "LoaderService").Start()};