function latestBuild([string]$artifactoryURL, [string]$buildName, [string]$repo="") {
    $searchURL="$($artifactoryURL)/api/build/$($buildName)"
    write-host "Retrieving latest version of build $buildName using [$searchURL]"

 	try {
		$searchresults=Invoke-RestMethod $searchURL

		if([string]::IsNullOrEmpty($searchresults.buildsNumbers)) {
			throw "No matching version of build $buildName from [$artifactoryURL]"
		} else {
			$results=@{}
			foreach($result in $searchresults.buildsNumbers) {
				$buildNumber=$result.uri.Substring(1)
				$lastModified=$result.started
                if ($repo -match "release") {
                    if ($buildNumber -match "-r" -or $buildName -match "Web") {
		    		    $results.Set_Item($buildNumber, $lastModified)
                    }
                } Else {
                    if ($repo -notmatch "release" -and $buildNumber -notmatch "-r") {
		    		    $results.Set_Item($buildNumber, $lastModified)
                    }
                }
			}
			$buildNumber = ($results.GetEnumerator() | sort Key -Descending | sort Value -Descending | select -First 1).Name
		}
        write-host "Found latest version of build $buildName is $buildNumber"
		return $buildNumber
	} catch {
		write-host "$_.Exception.Message"
	}
}
