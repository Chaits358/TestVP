function deploySnapshot([String]$envt, [String]$buildNumber) {

    $artifactoryURL="http://usdml.bpweb.bp.com:8088/artifactory"
    #constants
    $baseUrl = "http://sentosa.am.ist.bp.com/cc/api/commandcenterapi.svc/cc/"
    $complete = 4

    #package urls & key
    $startUrl = $baseUrl + "{key}/ex/?action=Start"
    $statusUrl = $baseUrl + "{key}/{packageInstanceId}/status/"
    $key="Deploy{ENV}AMDCMarketRiskGTELILApp"

    $key = $key.Replace("{ENV}", $envt )
    $startUrl = $startUrl.Replace( "{key}", $key )
    Write-Host "Calling Command Center Package $($key)"
    write-host "Command Center URL to deploy is $($startUrl)"
    $statusUrl = $statusUrl.Replace( "{key}", $key )

    #execute the job, setup the status url
    try {
        $response = Invoke-RestMethod $startUrl -Method Get -UseDefaultCredentials
    } catch {
        write-host "Encountered error during command centere job trigger " $Error
        exit 1
    }
    if ($response.InstanceId -eq "" -or $response.InstanceId -eq "0") {
    	write-host "Invalid package id in command center response"
    	exit 1
    }
    $statusUrl = $statusUrl.Replace( "{packageInstanceId}", $response.InstanceId )
    Write-Host "Started, Package Instance is: ", $response.InstanceId
    Write-Host "statusUrl is " $statusUrl

    #wait for complete
    Write-Host -NoNewline "Working"
    $response = Invoke-RestMethod $statusUrl -Method Get -UseDefaultCredentials
    while( $response.Status -lt $complete )
    {
        Write-Host -NoNewline "."
        $response = Invoke-RestMethod $statusUrl -Method Get -UseDefaultCredentials
        Start-Sleep -m 1000
    }

    #this is just a recursive dump of the adapter status
    Write-Host ""
    Write-Host "Package Complete:"
    $adapterStatusList = new-object System.Collections.Generic.Stack[System.Collections.IList]
    $adapterStatusList.Push( $response.Adapters )
    while( $adapterStatusList.Count -gt 0 )
    {
        $adapters = $adapterStatusList.Pop();
        foreach( $asm in $adapters )
        {
            Write-Host "Adapter Id: ", $asm.PackageAdapterId, "   Status:" $asm.StatusText, "   Message:", $asm.Message

            if($asm.StatusText -ne "Complete") {
                Write-Error "Error in adapter $($asm.PackageAdapterId)   Status: $($asm.StatusText)   Message: $($asm.Message)"
                write-error "Exiting here"
                exit 1
            }

            if( $asm.Adapters.Count -gt 0 )
            {
                $adapterStatusList.Push( $asm.Adapters );
            }
        }
    }

}
