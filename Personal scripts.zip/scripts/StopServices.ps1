$sourcelocation = "F:\GtelApp\continuous-deployment"

function stopServices()
{
	Write-Output "Stopping services"
	Stop-Process -processname AggregatorWebAutomationService
	Stop-Service AggregatorWebAutomationService
	Stop-Service LoaderService
	Stop-Service CacheService
	Stop-Service OrchestrationService
}

stopServices

Write-Output "Sleeping to make sure everything is shutdown"
Start-Sleep -s 10