$sourcelocation = "F:\GtelApp\continuous-deployment"
$wrapperlocation = "F:\wrapper-windows-x86-32-3.5.27"

function uninstallServices()
{
	Write-Output "Uninstalling services"
    cd $wrapperlocation
	.\bin\wrapper.exe -r $sourcelocation\config\loader.conf
	.\bin\wrapper.exe -r $sourcelocation\config\orchestration.conf
	.\bin\wrapper.exe -r $sourcelocation\config\cache.conf
}

uninstallServices
