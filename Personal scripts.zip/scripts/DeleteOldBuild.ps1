function deleteBuild([string]$artifactoryURL, [string]$artefact, [int]$startBuildNumber, [int]$endBuildNumber, [string]$repo="") {

    $buildNumber=$startBuildNumber
	try {
	    $user="tfjenkins"
	    $pass="Welcome1"
	    $passSS = ConvertTo-SecureString $pass -AsPlainText -Force
	    $cred=New-Object System.Management.Automation.PSCredential ($user, $passSS)
	    $credAuth=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($user):$($pass)"))

        while ($buildNumber -lt $endBuildNumber) {
            try {
                $deleteURL="$($artifactoryURL)/$($repo)/com/bp/risk/$($artefact)/1.0.$($buildNumber)"
                Write-Host $deleteURL
                $ServicePoint = [System.Net.ServicePointManager]::FindServicePoint($deleteURL)
                $status=Invoke-WebRequest -uri $deleteURL -Headers @{"Authorization"="Basic $credAuth"} -Method Delete -DisableKeepAlive
                $ServicePoint.CloseConnectionGroup("")
                write-host $status
            } catch {
                Write-Host $error[0]
            }
            $buildNumber=$buildNumber+1
        }
	} catch {
		write-host "Exception while identifying the latest version of build $artefact from [$artifactoryURL]" $error[0]
	}
}

$artifactoryUrl=$env:artifactoryUrl
$artefact=$env:artefact
$startBuildNumber=$env:startBuildNumber
$endBuildNumber=$env:endBuildNumber
$repo="bp-mrisk-snapshot"
deleteBuild $artifactoryURL $artefact $startBuildNumber $endBuildNumber $repo
