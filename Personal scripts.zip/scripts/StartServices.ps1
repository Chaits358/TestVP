function startServices()
{
	Write-Output "Starting Services"
	Start-Service LoaderService
	Start-Service CacheService
	Start-Service OrchestrationService
}

startServices

Write-Output "Sleeping to make sure everything is up and running"
Start-Sleep -s 60