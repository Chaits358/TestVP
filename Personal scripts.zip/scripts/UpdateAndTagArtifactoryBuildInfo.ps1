#using WebRequest as invoke-restmethod fails for non GET calls after 3 calls
function setProperties([string]$uri, [string]$credAuth) {
    $request = [System.Net.WebRequest]::Create($uri)
    $request.Method="PUT"
    $request.Headers.Add("Authorization","Basic $credAuth")
    $response = $request.GetResponse()
    $response.Dispose()
}

$user="tfjenkins"
$pass=$env:tfjenkins
$passSS = ConvertTo-SecureString $pass -AsPlainText -Force
$cred=New-Object System.Management.Automation.PSCredential ($user, $passSS)
$credAuth=[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("$($user):$($pass)"))

$artifactoryURL="http://usdml.bpweb.bp.com:8088/artifactory"
$buildNumber=$($env:BUILD_NUMBER).replace("#","")
$buildName=$env:JOB_NAME
$ReleaseTag="release.$($buildName.Trim())_$($buildNumber)"

Write-Output "Looking for all objects in Build $($buildName) (number $($buildNumber))"
$buildSearch="$($artifactoryURL)/api/build/$($buildName)/$($buildNumber)"

try {
   $buildInfo=(Invoke-RestMethod -uri $buildSearch).buildInfo
}
catch {
   write-host "Error while retrieving Build Info $($error[0])"
  exit 1
}

foreach ($module in $buildInfo.modules) {
    $moduleName=$module.id.split(":")[1]
    write-output "Processing module $($moduleName)"
    foreach($artifact in $module.artifacts) {
        write-output "Processing Artifact $($artifact.name)"
        $md5=$artifact.md5
        try {
            $urls = (Invoke-RestMethod -uri "$($artifactoryURL)/api/search/checksum?md5=$($md5)").results
            foreach($u in $urls) {
                if($moduleName -eq "mrisk-config") {
                    write-host "Processing mrisk-config. Trying to add classifier"
                    $comps=$artifact.name.split(".-")
                    $classifier=$comps[$comps.length-2]
                    if($classifier -eq "SNAPSHOT") {
                        $classifier="ALL"
                    }
                    write-host "Classifier retrieved as $($classifier)"
                    setProperties "$($u.uri)?properties=module=$($moduleName)-$($classifier)" $credAuth
                } else {
                    setProperties "$($u.uri)?properties=module=$($moduleName)" $credAuth
                }
            }
        }
        catch {
            write-host "Error while tagging artifact $($artifact.id) as module $($moduleName): $($error[0])"
            break
            exit 1
        }
    }
}
