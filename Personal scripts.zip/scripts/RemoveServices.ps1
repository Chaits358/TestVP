$sourcelocation = "F:\GtelApp\continuous-deployment"
$wrapperlocation = "F:\wrapper-windows-x86-32-3.5.27"

function removeServices()
{
	Write-Output "Removing services"
    cd $wrapperlocation
	.\bin\wrapper.exe -r $sourcelocation\config\loader.conf
	.\bin\wrapper.exe -r $sourcelocation\config\orchestration.conf
	.\bin\wrapper.exe -r $sourcelocation\config\cache.conf
}

removeServices

Write-Output "Sleeping to make sure everything is shutdown"
Start-Sleep -s 30
