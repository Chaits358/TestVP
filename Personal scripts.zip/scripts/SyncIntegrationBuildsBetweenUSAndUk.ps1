. .\GetLatestBuild.ps1

function syncBuilds([string]$buildName, [string]$repo, [string]$buildNo="") {

    $artifactoryURL="http://dml.bpweb.bp.com:8088/artifactory"
    $USArtifactoryUrl="http://usdml.bpweb.bp.com:8088/artifactory"

    try {
        if ($buildNo -ne "") {
            $buildNumber = $buildNo
        } else {
            $buildNumber = latestBuild $artifactoryURL $buildName $repo
        }
        write-host "Getting build content in UK for $($buildName) with buildNumber $($buildNumber)"
        $searchUrl="$($artifactoryURL)/api/search/prop?build.name=$($buildName)&build.number=$($buildNumber)"
        $buildContent=(Invoke-RestMethod -uri $searchUrl).results
        $md5s=@()
        $buildContent | %{$md5s+=(Invoke-RestMethod -uri "$($_.uri)").checksums.md5}
    }
    catch {
        write-host "Error while getting build content in UK"
        exit 1
    }

    $counter=0
    try {
        write-host "Getting build content in US for $($buildName) with buildNumber $($buildNumber)"
        while ($counter -lt 10) {
            $searchUrlUS="$($USartifactoryURL)/api/search/prop?build.name=$($buildName)&build.number=$($buildNumber)"
            $buildContentUS=(Invoke-RestMethod -uri $searchUrlUS).results
            $md5sUS=@()
            $buildContentUS | %{$md5sUS+=(Invoke-RestMethod -uri "$($_.uri)").checksums.md5}

            $c=@()
            $c += Compare-Object -ReferenceObject $md5s -DifferenceObject $md5sUS -PassThru

            if($c.Count -gt 0) {
                write-host "US Artifactory not synched yet"
                start-sleep -s 120
                $counter++
            } else {
                write-host "builds in sync between the 2 instances"
                break
            }
        }
    }
    catch {
        write-host "Error while getting build content in US"
        exit 1
    }
    return $buildNumber
}
