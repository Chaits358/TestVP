import requests
import os
import datetime
import sys
import shutil
import subprocess
import json

#################################################################################
############### Configure static parameters #####################################
#################################################################################

nexusiq_scan_endpoint = "http://we1p1almt00ld:8090"
nexus_cli_jar = "nexus-iq-cli-1.59.0-01.jar"
nexus_app_id = "com.testapp"
nexus_user = "admin"
nexus_password = ""
nexus_headers = {
    'Authorization': "Basic YWRtaW46V2VsY29tZTEyMw==",
    'cache-control': "no-cache"
}

dml_repo = 'bp-sharepoint-nuget-local'
dml_url = "https://dml.bpweb.bp.com/artifactory/api/archive/download/" + \
    dml_repo + "?archiveType=zip"
dml_headers = {
    'X-JFrog-Art-Api': "AKCp5aUjFxMr8By6uBu77VoBFCnsapMz4Ycu4G9KcciS2PbT2kj8A6ia53cEGBfRW4CnyYaYv",
    'cache-control': "no-cache"
}
dml_repo_list_url="https://dml.bpweb.bp.com/artifactory/api/storageinfo"

splunk_url = "https://splunksandbox.bpweb.bp.com:8088/services/collector/event"
splunk_hec_headers = {
    'Authorization': "Splunk 8e36f7fe-1f03-470c-bb84-0352105ac900",
    'Content-Type': "application/json"
}

#############################################################################################
############### End Configure static parameters section #####################################
#############################################################################################

#################################################################################
############### Different methods for various functionalities ###################
#################################################################################

def getAppPublicId(appId, nexus_url, nexus_headers):
    querystring = {"publicId": appId}
    apiEndPoint = nexus_url+"/api/v2/applications"
    payload = ""
    res = requests.request("GET", apiEndPoint, data=payload,
                           headers=nexus_headers, params=querystring)
    json_res = res.json()
    #print type(json_res)
    return json_res['applications'][0]['publicId']


def getScanReport(appPublicId, lifecyclescan_report_id, nexusiq_scan_endpoint, nexus_headers):
    apiEndPoint = nexusiq_scan_endpoint + \
        "/api/v2/applications/" + appPublicId + \
        "/reports/" + lifecyclescan_report_id
    payload = ""
    #print apiEndPoint
    res = requests.request(
        "GET", apiEndPoint, data=payload, headers=nexus_headers)
    if res.status_code == 200:
        json_res = res.json()
        return json_res
    else:
        print ("Error fetching scan report. Details below")
        print res


def send_data_to_splunk(splunk_url, splunk_headers, payload_data):
    payload = "{\"event\" : "+payload_data+"}"
    splunk_response = requests.request(
        "POST", splunk_url, data=payload, headers=splunk_headers, verify=False)
    splunk_res = splunk_response.json()
    if splunk_res['text'] == "Success":
        return True
    else:
        print "Unable to send data to Splunk. Response is "
        print splunk_response
        return False

##################################################################
########### Main Function starts here ############################
##################################################################
dml_repo_res = requests.get(dml_repo_list_url, headers=dml_headers, verify=False)
dmls_repos_json = dml_repo_res.json()
for repo in dmls_repos_json['repositoriesSummaryList']:
    if repo['repoType'] == "LOCAL" and repo['repoKey'] != "TOTAL" :
        dml_repo = repo['repoKey']
        local_filename = dml_repo + ".zip"
        dml_url = "https://dml.bpweb.bp.com/artifactory/api/archive/download/" + \
    dml_repo + "?archiveType=zip"
        r = requests.get(dml_url, stream=True, headers=dml_headers, verify=False)
        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=4076):
                if chunk:
                    f.write(chunk)

        textchars = bytearray({7, 8, 9, 10, 12, 13, 27} |
                            set(range(0x20, 0x100)) - {0x7f})


        def is_binary_string(bytes): return bool(bytes.translate(None, textchars))


        f.close()

        with open(local_filename, 'r') as repoarchive:
            if is_binary_string(repoarchive.read(1024)):
                print(
                    "File is binary and repo is downloaded into zip file. Continuing with the scan")
            else:
                print("Downloaded file is a text file, which means there is an error. Here is the content.")
                shutil.copyfile(local_filename, local_filename+".json")
                error = open(local_filename+".json", 'r')
                message = error.read()
                print(message)
                error.close()


        repoarchive.close()
        r.close()


        # Pass the archive for Nexus Regular LifeCycle Scan
        try:
            p = subprocess.Popen(["java", "-jar", nexus_cli_jar, "-i", nexus_app_id, "-s", nexusiq_scan_endpoint,
                                "-a", nexus_user+":"+nexus_password, dml_repo+".zip"], stdout=file("stdout_standard_scan.log", mode='a'), stderr=file("stderr_scan.log", mode='a'))
        except Exception, e:
            print("An error occured while running the CLI Scan. \n " + str(e))
            sys.exit()

        p.wait()

        print("Attempted Lifecycle scan, checking for errors & gathering the scan analysis reports for the repo "+dml_repo)
        if os.stat("stderr_scan.log").st_size == 0:
            print("No errors in scan standard error stream")
            if os.path.exists("./stdout_standard_scan.log"):
                stdout_log_file = open("./stdout_standard_scan.log", "r")
                for line in stdout_log_file:
                    if "[ERROR]" in line:
                        print("There is an error while running the scan \n"+line)
                    elif "[INFO] The detailed report can be viewed" in line:
                        lifecylescan_report_url = line.split(" at ")[1].strip()
                        lifecyclescan_report_id = lifecylescan_report_url.split(
                            "/")[-1]
                        appPublicId = getAppPublicId(
                            nexus_app_id, nexusiq_scan_endpoint, nexus_headers)
                        jsonreport = getScanReport(
                            appPublicId, lifecyclescan_report_id, nexusiq_scan_endpoint, nexus_headers)
                        #print type(jsonreport)
                        #print jsonreport
                        if jsonreport:
                            splunk_json = json.dumps(jsonreport)
                            if send_data_to_splunk(splunk_url, splunk_hec_headers, splunk_json):
                                print "Data sent to Splunk"
                            else:
                                print "Failure while sending data to Splunk"
                        else:
                            print "Error fetching scanned report."
                    else:
                        continue
        else:
            print("Errors during the scan")


        # Pass the archive for Nexus Regular LifeCycle xc Scan
        try:
            p = subprocess.Popen(["java", "-jar", nexus_cli_jar, "-xc", "-i", nexus_app_id, "-s", nexusiq_scan_endpoint,
                                "-a", nexus_user+":"+nexus_password, dml_repo+".zip"], stdout=file("stdout_xc_scan.log", mode='a'), stderr=file("stderr_xc_scan.log", mode='a'))
        except Exception, e:
            print("An error occured while running the CLI Scan. \n " + str(e))
            sys.exit()
        p.wait()
        print("Attempted Lifecycle XC scan, checking for errors and gathering the scan analysis reports for the repo "+dml_repo)

        if os.stat("stderr_xc_scan.log").st_size == 0:
            print("No errors in XC scan stand error stream")
            if os.path.exists("./stdout_xc_scan.log"):
                stdout_xc_log_file = open("./stdout_xc_scan.log", "r")
                for line in stdout_xc_log_file:
                    if "[ERROR]" in line:
                        print("There is an error during the scan \n"+line)
                    elif "[INFO] The expanded coverage report can be viewed" in line:
                        xc_lifecylescan_report_url = line.split(" at ")[1].strip()
                        xc_lifecyclescan_report_id = xc_lifecylescan_report_url.split(
                            "/")[-1]
                        appPublicId = getAppPublicId(
                            nexus_app_id, nexusiq_scan_endpoint, nexus_headers)
                        xc_jsonreport = getScanReport(
                            appPublicId, xc_lifecyclescan_report_id, nexusiq_scan_endpoint, nexus_headers)
                        if xc_jsonreport:
                            splunk_json = json.dumps(xc_jsonreport)
                            if send_data_to_splunk(splunk_url, splunk_hec_headers, splunk_json):
                                print "Data sent to Splunk"
                            else:
                                print "Failure while sending data to Splunk"
                        else:
                            print "Error fetching XC report."
                    else:
                        continue
        else:
            print("Errors during the XC scan")

        stdout_log_file.close()
        stdout_xc_log_file.close()

        os.remove("./stdout_xc_scan.log")
        os.remove("./stderr_xc_scan.log")
        os.remove("./stderr_scan.log")
        os.remove("./stdout_standard_scan.log")
        os.remove("./"+local_filename)
