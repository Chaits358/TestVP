This script needs

1) Java installed on the server
2) Python with following packages installed

requests
os
datetime
sys
shutil
subprocess
json

3) Connectivity to the following URLs/Ports

dml.bpweb.bp.com:8088
we1p1almt00ld:8090


4) File to updated with passwords and tokens to Splunk, DML and nexus in the variables at initial section of the page